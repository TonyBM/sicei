package mx.uady.sicei.model;

public enum Licenciatura {
    LIS,
    LCC,
    LIC,
    LA,
    LM
}
